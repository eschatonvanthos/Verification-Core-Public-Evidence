# Verification Report

## 1. Scope and interpretation

This report summarizes evidence supplied for the Verification Core project. Results are stated within their actual test scope. A test pass is not a general proof of correctness, security, or production suitability.

## 2. Formal-model evidence

The project journal records an integrated SMT regression involving 17 files and 129 checks:

- 129 `UNSAT`
- 0 `SAT`
- 0 `UNKNOWN`
- 0 solver errors
- Z3 version recorded in the journal: 4.16.0

The journal also records a separate earlier 15-file run with 60 `UNSAT` results, and an intermediate 17-file run with 66 `UNSAT` results. The later integrated 129-check run is the relevant consolidated result reported here.

The formal checks concern the properties encoded in the SMT artifacts and their stated constraints. They do not independently establish the authenticity of external evidence, implementation conformance, operational safety, or certification.

## 3. Software-core evidence

### MINIMAL-V1

The V1 unit-test suite was executed again in the current verification session:

- 13 tests run
- 13 passed
- 0 failures
- 0 errors

### MINIMAL-V2

The V2 unit-test suite was executed again in the current verification session:

- 18 tests run
- 18 passed
- 0 failures
- 0 errors

### V1/V2 finite comparison

The project journal records 729 matching comparisons and zero mismatches, with each of C1, C2, and C3 drawn from the finite integer range `[-3, 5]`.

This is finite-domain evidence. It is not a universal equivalence proof over all possible inputs.

### V2 reference-function comparison

A separate user-executed check compared V2 outputs with independently written reference functions over the same finite input domain:

- 729 combinations checked
- 0 mismatches
- invalid-input checks passed for the tested cases:
  - `normalize(True)` → `TypeError`
  - `normalize(1.5)` → `TypeError`
  - `and3(0, 3)` → `ValueError`
  - `decide(3)` → `ValueError`

The reference functions were written in the test procedure. This is an independent comparison procedure, not independent third-party verification.

The V1/V2 comparison and the V2/reference comparison are distinct procedures over the same finite input domain. They must not be added together and presented as 1,458 unique input combinations.

## 4. GUI evidence

The available project history records manual Android checks for GUI V1.1, including sign toggling, recalculation after input changes, and submission of negative and mixed values. The recorded manual checks passed.

The GUI V1.1 archive was checked:

- archive SHA-256: `48df2a348b0002da6e17f5aa8e14e2b594608032d4eec01eda389ad0a2fa9579`
- sidecar SHA-256 matched the archive hash;
- ZIP integrity test reported all five members as `OK`;
- no compressed-data errors were reported.

Archive integrity confirms that the archived members can be read and that the supplied checksum matches. It does not establish application correctness or security.

## 5. Evidence distinctions

The following results are separate and must remain separately reported:

- SMT formal-model checks: 129 checks.
- V1 unit tests: 13 tests.
- V2 unit tests: 18 tests.
- V1/V2 finite comparison: 729 combinations.
- V2/reference finite comparison: 729 combinations.
- GUI manual Android checks: limited manual test set.
- Archive integrity checks: packaging and checksum integrity.

The historical figure of 942 checks is not included as a confirmed result in this report because the primary evidence currently available does not establish a reproducible calculation for that figure.

## 6. Verification conclusion

The available evidence supports successful execution of the listed test suites and checks within their documented scopes. It does not support a claim of universal mathematical proof, independent third-party verification, comprehensive security testing, industrial readiness, or safety certification.
