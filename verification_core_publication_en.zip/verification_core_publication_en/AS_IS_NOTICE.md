# AS IS Notice

Verification Core and the accompanying documentation are presented in their currently documented state and are provided **“AS IS”**, to the extent permitted by applicable law.

The published materials describe the available functional model, recorded implementation characteristics, test results, evidence boundaries, and known limitations. No representation is made that the product is defect-free, fit for a particular purpose, production-ready, industrially certified, or suitable for safety-critical deployment.

The reported tests and formal-model checks are limited to the scopes expressly described in the documentation. They do not constitute independent third-party certification or a guarantee of operational safety.

The publication of this notice does not itself establish a software license, transfer intellectual-property rights, define commercial terms, or replace a legally reviewed agreement. Licensing, permitted use, support, liability, and transaction terms must be addressed separately.
