# Test and Evidence Matrix

| Area | Evidence | Result | Status | Scope limitation |
|---|---|---:|---|---|
| SMT formal model | Journaled integrated suite, 17 files | 129 UNSAT; 0 SAT; 0 UNKNOWN; 0 solver errors | Reported PASS | Applies to encoded properties and constraints only |
| Core MINIMAL-V1 | Re-executed Python unit tests | 13/13 PASS | TESTED / PASS | Does not establish behavior outside test coverage |
| Core MINIMAL-V2 | Re-executed Python unit tests | 18/18 PASS | TESTED / PASS | Does not establish behavior outside test coverage |
| V1/V2 comparison | Finite input enumeration | 729 MATCH; 0 MISMATCH | TESTED / PASS | C1, C2, C3 each in `[-3, 5]` |
| V2/reference comparison | Separate reference-function procedure | 729 MATCH; 0 MISMATCH | TESTED / PASS | Same finite domain; reference procedure is not third-party audited |
| Invalid V2 inputs | Four explicit cases | 4/4 expected exceptions | TESTED / PASS | Only the listed cases |
| GUI V1.1 | Manual Android checks recorded in project history | Limited manual checks passed | MANUAL TEST EVIDENCE | Not an exhaustive GUI test suite |
| GUI V1.1 archive | SHA-256 sidecar and ZIP integrity test | Hash matched; 5 members OK | INTEGRITY PASS | Does not prove runtime correctness |
| GUI on Ubuntu | No runtime evidence supplied | Not established | NOT TESTED | Runtime compatibility unknown |
| GUI on Windows | No runtime evidence supplied | Not established | NOT TESTED | Runtime compatibility unknown |
| Security assessment | No comprehensive audit evidence supplied | Not established | NOT TESTED | No security certification claim |

## Counting rules

Do not combine the counts above into one total. They represent different methods, artifacts, and scopes. In particular, the two 729-combination procedures use the same finite input domain and are not 1,458 unique input combinations.

The historical figure of 942 is excluded from confirmed totals because its derivation has not been reproduced from the primary evidence currently available.
