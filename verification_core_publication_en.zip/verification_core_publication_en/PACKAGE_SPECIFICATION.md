# Package Specification

## 1. Purpose

Verification Core is a decision-processing component that evaluates exactly three input conditions using a three-valued logic model. It returns an acceptance, rejection, or unknown decision.

The central behavioral rule is that uncertainty is preserved. The system must not convert an unknown aggregate condition into `ACCEPT`.

## 2. Value model

The implementation uses the following integer representation:

| Integer | Condition meaning | Decision meaning |
|---:|---|---|
| `0` | `TRUE` | `ACCEPT` |
| `1` | `UNKNOWN` | `UNKNOWN` |
| `2` | `FALSE` | `REJECT` |

Condition values and decision values use the same integer symbols but belong to conceptually distinct domains.

## 3. Functional operations

The documented Core V2 operations are:

### `normalize(value)`

Accepts an integer and maps it to the condition domain:

- `0` remains `0`.
- `2` remains `2`.
- Any other integer becomes `1` (`UNKNOWN`).
- Values that are not Python integers are rejected with `TypeError`.

The supplied V2 implementation uses strict type checking (`type(value) is int`); therefore, Python booleans are not accepted as integers by this interface.

### `and3(x, y)`

Accepts two values from `{0, 1, 2}`:

- If either operand is `2`, the result is `2`.
- If both operands are `0`, the result is `0`.
- Otherwise, the result is `1`.

Operands outside the domain are rejected with `ValueError`.

### `aggregate(c1, c2, c3)`

Normalizes exactly three raw integer inputs and combines them using `and3`.

### `decide(q)`

Maps an aggregate value to a decision:

- `0` → `ACCEPT` (`0`)
- `2` → `REJECT` (`1`)
- `1` → `UNKNOWN` (`2`)

Values outside `{0, 1, 2}` are rejected with `ValueError`.

## 4. Decision behavior

| C1 | C2 | C3 | Aggregate Q | Decision |
|---:|---:|---:|---:|---|
| `0` | `0` | `0` | `0` | `ACCEPT` |
| `0` | `1` | `0` | `1` | `UNKNOWN` |
| `0` | `2` | `0` | `2` | `REJECT` |
| `1` | `1` | `1` | `1` | `UNKNOWN` |
| `2` | `1` | `1` | `2` | `REJECT` |

The table illustrates the three-valued conjunction; it is not a substitute for the full truth table.

## 5. Component boundaries

The available project materials describe three distinct layers:

1. **Formal model:** SMT artifacts and checks of encoded properties.
2. **Software core:** MINIMAL-V1 and MINIMAL-V2 implementations of the documented operations.
3. **User interface:** GUI V1.1, a local browser-based interface that invokes Core V2.

Evidence for one layer must not be interpreted automatically as evidence for another. In particular, satisfiability results for an SMT model do not, by themselves, prove that a software implementation conforms to that model.

## 6. GUI V1.1 architecture

The supplied GUI V1.1 source was inspected. It uses Python standard-library modules and a local HTTP server bound to `127.0.0.1` on an automatically assigned port. It serves the browser interface and handles a calculation request at `/calculate`.

The interface accepts three integer inputs, provides sign toggles, submits the values to the local server, and displays normalized conditions, the aggregate value, and the decision.

The server's printed message `NETWORK ACCESS: DISABLED` is not treated as proof of comprehensive network isolation or security. The evidence supports the loopback binding described above, not a complete security assessment.

## 7. Current package boundary

This publication documents the existing model, implementation behavior as evidenced by the supplied tests, and the GUI architecture. It does not claim that the project currently provides:

- a public network API;
- a database or persistent decision store;
- authentication or authorization;
- a message-queue connector;
- a production integration adapter;
- a distributed execution service;
- a certified safety mechanism.

A proposed integration architecture is documented separately in `INTEGRATION_ARCHITECTURE.md`.
