# Third-Party System Integration Architecture

## 1. Status: proposed architecture

This document describes a proposed integration pattern for connecting Verification Core to third-party systems. It is an architectural proposal, not a claim that the current Core V2 or GUI V1.1 already exposes a production API, network service, connector, authentication mechanism, or message-queue integration.

The current documented software core provides local callable functions. The GUI V1.1 provides a local browser interface and a loopback-bound HTTP handler. A production integration layer would be additional software requiring its own specification, implementation, and verification.

## 2. Design objective

Keep the decision logic isolated from external systems:

- external systems own their data, identity, permissions, and workflows;
- an adapter translates external data into the Core's three condition inputs;
- the Core calculates the result;
- the adapter translates the result into a documented response;
- the external system decides what action, if any, follows.

The Core should not silently perform external actions. A returned `ACCEPT` is a decision result, not authorization to execute an unrelated downstream operation.

## 3. Logical integration flow

```text
Third-Party System
       |
       | 1. Request with three condition values
       v
Integration Adapter
       |
       | 2. Schema and type validation
       | 3. Map external values to Core input integers
       v
Verification Core
       |
       | 4. normalize -> aggregate -> decide
       v
Integration Adapter
       |
       | 5. Map result and attach trace metadata
       v
Third-Party System
       |
       | 6. Apply its own workflow policy
       v
Optional Human Review / Downstream Process
```

## 4. Proposed adapter responsibilities

The adapter should:

1. Authenticate and authorize the calling system, if exposed across a trust boundary.
2. Validate request structure, types, required fields, and size limits.
3. Map each external condition to the Core's documented input domain.
4. Reject malformed requests rather than silently coercing ambiguous values.
5. Call the Core's `aggregate` and `decide` operations.
6. Return the decision and a traceable request identifier.
7. Record operational metadata according to the host system's audit policy.
8. Apply timeouts, rate limits, and availability controls appropriate to the deployment.
9. Avoid logging secrets or unnecessary personal data.
10. Ensure retries do not cause duplicate downstream actions.

These are proposed adapter requirements; they are not currently verified Core V2 features.

## 5. Proposed logical request contract

An illustrative JSON request could be:

```json
{
  "request_id": "caller-generated-unique-id",
  "policy_id": "three-condition-policy-v1",
  "conditions": {
    "c1": 0,
    "c2": 1,
    "c3": 0
  },
  "context_ref": "external-record-reference"
}
```

Field intent:

| Field | Meaning |
|---|---|
| `request_id` | Caller-generated identifier for traceability and retry handling |
| `policy_id` | Identifier for the external policy or mapping version |
| `conditions.c1` | First integer condition |
| `conditions.c2` | Second integer condition |
| `conditions.c3` | Third integer condition |
| `context_ref` | Optional reference to the caller's record; avoid sending unnecessary personal data |

This is an illustrative contract only. It is not an implemented endpoint or an approved final API schema.

## 6. Proposed logical response contract

An illustrative response could be:

```json
{
  "request_id": "caller-generated-unique-id",
  "normalized_conditions": {
    "c1": 0,
    "c2": 1,
    "c3": 0
  },
  "aggregate": 1,
  "decision": {
    "code": 2,
    "label": "UNKNOWN"
  },
  "core_version": "MINIMAL-V2",
  "policy_id": "three-condition-policy-v1"
}
```

The response should distinguish the aggregate condition value from the decision code. In Core V2, aggregate `1` maps to decision code `2` (`UNKNOWN`).

A production API should also define structured error responses for malformed input, unsupported versions, authorization failures, timeouts, and internal failures. Those response codes are not specified by the current Core implementation.

## 7. Integration patterns

Potential deployment patterns include:

### A. In-process library integration

A host application imports or invokes the Core within the same process.

- Lowest integration complexity.
- No network boundary between the host and Core.
- Requires compatible runtime and controlled dependency management.
- The current source-level functions are consistent with this general pattern, but a distributable library contract and versioning policy would still need to be defined.

### B. Local service adapter

A separate local adapter exposes a controlled interface to a host application.

- Can isolate the Core from the host application's user interface.
- Requires explicit process management, access control, logging, and failure handling.
- The current GUI's loopback HTTP server is not, by itself, a production integration service.

### C. Network API adapter

A separately implemented service exposes an authenticated API to remote systems.

- Requires transport security, authentication, authorization, request validation, rate limiting, monitoring, and operational controls.
- Must not expose the current development GUI handler as a production API without a separate security and architecture review.

### D. Message-based integration

An adapter consumes events or messages from a queue or event bus and returns or publishes a decision result.

- Requires message schema versioning, correlation identifiers, retry policy, duplicate handling, dead-letter handling, and ordering rules.
- No message-queue connector is currently documented as implemented.

## 8. Error and uncertainty handling

The integration layer must not treat all failures as `UNKNOWN` without a defined policy. Distinguish at least:

- a valid Core result of `UNKNOWN`;
- malformed input rejected before Core execution;
- unavailable Core or adapter;
- timeout;
- unauthorized request;
- downstream system failure.

The host system must define what happens in each case. For safety-sensitive or consequential workflows, failure handling and human escalation require domain-specific hazard analysis and validation.

## 9. Security and trust boundaries

The Core's decision logic does not replace the security responsibilities of the integrating system.

A production integration design should address:

- authenticated caller identity;
- authorization and least privilege;
- encrypted transport where communication crosses a trust boundary;
- input validation and resource limits;
- secret management;
- audit logging and retention;
- data minimization;
- replay and duplicate-request handling;
- dependency and deployment integrity;
- monitoring and incident response.

No claim is made that these controls are implemented or audited in the current Core V2 or GUI V1.1.

## 10. Versioning and traceability

A production integration should record, at minimum:

- Core version;
- adapter version;
- request identifier;
- policy/mapping version;
- timestamp from the integrating system;
- input provenance or external record reference;
- normalized conditions;
- aggregate value and decision;
- error status, if any.

Changes to condition semantics or decision mapping should create a new explicitly identified policy or interface version. Historical decisions should remain interpretable using the version that produced them.

## 11. Integration verification plan

Before release of any adapter, verify:

1. Mapping of every external condition value.
2. Preservation of `UNKNOWN`.
3. Correct distinction between aggregate values and decision codes.
4. Invalid-type and malformed-request handling.
5. Timeout and service-unavailable behavior.
6. Authentication and authorization controls.
7. Retry, duplicate, and replay behavior.
8. Audit trace completeness.
9. Compatibility across supported Core and adapter versions.
10. Failure isolation and recovery.

These are proposed verification requirements, not completed tests.
