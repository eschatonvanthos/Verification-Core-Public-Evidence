# Known Limitations and Work Required

## 1. Evidence limitations

- SMT results apply to properties encoded in the supplied formal artifacts and their constraints.
- SMT results do not, by themselves, prove that the software implementation conforms to the formal model.
- Unit-test success establishes only the behavior exercised by those tests.
- The 729-combination comparisons cover a finite input range: each of C1, C2, and C3 is in `[-3, 5]`.
- The reference-function comparison was executed as a separate procedure but was not an independent third-party audit.
- GUI evidence is limited to the recorded manual Android checks.
- GUI runtime on Ubuntu and Windows has not been established by the evidence summarized here.
- Archive integrity does not establish application correctness, security, or suitability.

## 2. Implementation and interface limitations

The available evidence does not establish a production-ready:

- public API;
- authentication or authorization layer;
- database or persistent decision store;
- audit service;
- distributed service;
- message-queue connector;
- third-party adapter;
- deployment and update mechanism.

The proposed integration architecture is a design direction only.

## 3. Security limitations

No comprehensive security audit, penetration test, threat model, cryptographic review, or formal security certification is established by the available evidence.

The GUI's loopback binding is a useful architectural fact, but it is not a complete security guarantee.

## 4. Work required before production adoption

The exact work depends on the target application. A responsible production-readiness program would normally define and assess:

1. Requirements and domain semantics for all three conditions.
2. Traceability from requirements to formal properties, implementation, and tests.
3. Implementation-to-specification conformance tests.
4. Expanded boundary, malformed-input, property-based, and robustness tests.
5. Failure, interruption, recovery, and resource-exhaustion behavior.
6. Security threat model and security testing.
7. Integration adapter and API contracts, if required.
8. Deployment, configuration, monitoring, backup, and update procedures.
9. Human review and escalation policy for unknown or failed decisions.
10. Independent assessment and applicable regulatory or certification requirements.

## 5. No industrial-readiness claim

The current evidence does not justify describing Verification Core as industrially certified, production-ready, or suitable for safety-critical deployment.
