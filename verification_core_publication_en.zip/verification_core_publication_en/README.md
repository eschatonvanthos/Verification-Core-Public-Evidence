# Verification Core

**Public technical documentation package**  
**Documentation status:** Draft for technical publication  
**Implementation source code:** Not included

## Overview

Verification Core is a small decision-processing component based on three-valued logic. It accepts three input conditions, normalizes them, aggregates them using a three-valued conjunction, and maps the aggregate result to one of three decisions:

- `ACCEPT`
- `REJECT`
- `UNKNOWN`

The design preserves uncertainty: an unknown condition does not become an acceptance.

This package documents the available specifications, reported verification results, known limitations, potential application areas, and a proposed integration architecture. It does not provide the implementation source code.

## Package contents

- `PACKAGE_SPECIFICATION.md` — functional model, component boundaries, and current architecture.
- `VERIFICATION_REPORT.md` — available formal-model, software-test, GUI, and archive evidence.
- `TEST_MATRIX.md` — test coverage and evidence status.
- `POTENTIAL_APPLICATIONS.md` — illustrative application areas requiring domain-specific validation.
- `INTEGRATION_ARCHITECTURE.md` — proposed third-party integration pattern; not an implemented API specification.
- `LIMITATIONS.md` — known limitations and work required before production use.
- `AS_IS_NOTICE.md` — status and warranty disclaimer.
- `ARTIFACT_MANIFEST.sha256` — SHA-256 fingerprints for this documentation package.

## Important status statement

The published evidence supports the specific tests and checks described in this package. It does not establish industrial readiness, safety certification, independent third-party certification, or suitability for safety-critical deployment.

The GUI described here is a local browser-based interface. Runtime verification on Ubuntu and Windows has not been established by the evidence summarized here.

## Suggested reading order

1. `PACKAGE_SPECIFICATION.md`
2. `VERIFICATION_REPORT.md`
3. `TEST_MATRIX.md`
4. `POTENTIAL_APPLICATIONS.md`
5. `INTEGRATION_ARCHITECTURE.md`
6. `LIMITATIONS.md`
7. `AS_IS_NOTICE.md`
